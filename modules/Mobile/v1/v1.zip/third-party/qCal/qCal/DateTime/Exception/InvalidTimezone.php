<?php
class qCal_DateTime_Exception_InvalidTimezone extends qCal_DateTime_Exception {}